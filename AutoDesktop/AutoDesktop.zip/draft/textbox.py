from pyautogui import *


a = "Capslock"
press(a)
a = a.lower()
print(a)
press(a)

