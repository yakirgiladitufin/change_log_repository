from tkinter import *
import time

def show_entry_fields():
   print("First Name: %s\nLast Name: %s" % (e1.get()))
def OK():
	pass


insert_filename_fm = Tk()
            
insert_filename_fm.geometry("250x100")
insert_filename_fm.title("Script Name")

lb_coutdown_var = StringVar(insert_filename_fm)
lb_coutdown_var.set("3")
Label(insert_filename_fm, text="Countdown to Running:", font=("Helvetica", 15)).pack(side="top", fill='both', expand=True)
lb_coutdown = Label(insert_filename_fm, textvariable=lb_coutdown_var, font=("Helvetica", 25))
lb_coutdown.pack(side="top", fill='both', expand=True)


for i in range(3,0,-1):
	print(i)
	time.sleep(1)
	text = str(i)
	lb_coutdown_var.set(text)





